from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("https://www.saucedemo.com/")

driver.find_element(By.ID, "user-name").send_keys("standard_user")
driver.find_element(By.ID, "login-button").click()

time.sleep(2)

driver.save_screenshot("empty_password.png")

print("PASS")

driver.quit()